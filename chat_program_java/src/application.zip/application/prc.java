package application;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
//import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Popup;
import javafx.stage.Stage;
public class PychatController implements Initializable  {
	
	private Stage Stage;
	
	@FXML
	private TextField textBox1;
	
	@FXML
	private TextArea textBox2;
	@FXML
    private Button sendButton;
	
	@FXML
	private Button Write;
	private String Message;
	
		
	@FXML
	public void sendMessage(ActionEvent Action) {
		Message = textBox1.getText();
		textBox1.setText("");
		textBox2.setText(Message);
		
	}
	
	@FXML
	public void goWrite() {
		Stage = (Stage)Write.getScene().getWindow();
		Popup pop =new Popup();
		try {
			Parent root = FXMLLoader.load(getClass().getResource("Pyworld01.fxml"));
			pop.getContent().add(root);
			pop.setAutoHide(true);
			pop.show(Stage);
		}catch(IOException e) {
			e.printStackTrace();
		}
		
}
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		
	}
}